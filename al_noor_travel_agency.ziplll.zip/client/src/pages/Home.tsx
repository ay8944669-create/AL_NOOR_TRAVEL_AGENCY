import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Home() {
  // The userAuth hooks provides authentication state
  // To implement login/logout functionality, simply call logout() or redirect to getLoginUrl()
  let { user, loading, error, isAuthenticated, logout } = useAuth();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const sendMessageMutation = trpc.contact.sendMessage.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await sendMessageMutation.mutateAsync(formData);
      toast.success("Message sent successfully! We will contact you soon.");
      setFormData({ name: "", email: "", phone: "", message: "" });
    } catch (error) {
      toast.error("Failed to send message. Please try again.");
      console.error("Form submission error:", error);
    }
  };

  const phoneNumber = "+91 8828317105";
  const whatsappNumber = "918828317105";

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-red-600 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <img src="/manus-storage/al_noor_logo_red_white_8a8f185f.png" alt="AL NOOR Logo" className="h-16 w-16 object-contain" />
          </div>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex gap-8">
            <a href="#home" className="hover:text-red-100 transition">Home</a>
            <a href="#about" className="hover:text-red-100 transition">About Us</a>
            <a href="#manpower" className="hover:text-red-100 transition">Manpower</a>
            <a href="#training" className="hover:text-red-100 transition">Training</a>
            <a href="#services" className="hover:text-red-100 transition">Services</a>
            <a href="#contact" className="hover:text-red-100 transition">Contact</a>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-red-700 px-4 py-4 space-y-3">
            <a href="#home" className="block hover:text-red-100 transition">Home</a>
            <a href="#about" className="block hover:text-red-100 transition">About Us</a>
            <a href="#manpower" className="block hover:text-red-100 transition">Manpower</a>
            <a href="#training" className="block hover:text-red-100 transition">Training</a>
            <a href="#services" className="block hover:text-red-100 transition">Services</a>
            <a href="#contact" className="block hover:text-red-100 transition">Contact</a>
          </div>
        )}
      </nav>

      {/* Visitor Counter */}
      <div className="bg-white text-right pr-8 py-2 text-sm text-gray-600 border-b">
        Visitors: <span className="font-semibold">1822</span>
      </div>

      {/* Hero Section */}
      <section id="home" className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-red-600 font-semibold mb-2 text-sm">WELCOME TO</p>
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">AL NOOR TRAVEL AGENCY</h1>
              <p className="text-xl text-gray-600 mb-6">Your Trusted Partner in Gulf Recruitment & Overseas Placement</p>
              
              <p className="text-gray-700 mb-4 font-semibold">Dear Associates,</p>
              <p className="text-gray-700 mb-4 leading-relaxed">
                I am RAMZAN SHAIKH, founder of AL NOOR TRAVEL AGENCY, a trusted and reliable name in manpower recruitment and overseas placement services.
              </p>
              <p className="text-gray-700 mb-6 leading-relaxed">
                We specialize in supplying skilled and unskilled manpower to leading companies across United Arab Emirates, Saudi Arabia, Qatar, Bahrain, and other Gulf countries. Our commitment to excellence and professionalism has made us the preferred choice for recruitment needs.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Button className="bg-red-600 hover:bg-red-700 text-white font-semibold px-8 py-3">Apply Now</Button>
                <Button variant="outline" className="border-red-600 text-red-600 hover:bg-red-50 font-semibold px-8 py-3">Contact Us</Button>
                <a href={`https://wa.me/${whatsappNumber}?text=Hello%20AL%20NOOR%20TRAVEL%20AGENCY`} target="_blank" rel="noopener noreferrer">
                  <Button className="bg-green-500 hover:bg-green-600 text-white font-semibold px-8 py-3">
                    WhatsApp
                  </Button>
                </a>
              </div>
            </div>

            {/* Right side box */}
            <div className="bg-red-600 text-white p-12 rounded-2xl text-center">
              <h2 className="text-4xl font-bold mb-4">AL NOOR</h2>
              <p className="text-2xl font-semibold mb-4">TRAVEL AGENCY</p>
              <p className="text-lg">Your Trusted Partner in Gulf Recruitment</p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="bg-red-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold mb-4 text-center">About Us</h2>
          <p className="text-center text-red-100 mb-12 text-lg">Discover our mission, vision, and commitment to excellence</p>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-red-800 p-8 rounded-lg border-l-4 border-yellow-400">
              <div className="text-4xl mb-4">🎯</div>
              <h3 className="text-2xl font-bold mb-4">Our Mission</h3>
              <p className="text-red-100">To provide exceptional manpower recruitment and overseas placement services that connect skilled professionals with leading Gulf employers.</p>
            </div>
            <div className="bg-red-800 p-8 rounded-lg border-l-4 border-yellow-400">
              <div className="text-4xl mb-4">🏢</div>
              <h3 className="text-2xl font-bold mb-4">Our Vision</h3>
              <p className="text-red-100">To be the most trusted recruitment partner in the Gulf region, known for professionalism, reliability, and successful placements.</p>
            </div>
            <div className="bg-red-800 p-8 rounded-lg border-l-4 border-yellow-400">
              <div className="text-4xl mb-4">👥</div>
              <h3 className="text-2xl font-bold mb-4">Our Team</h3>
              <p className="text-red-100">Experienced professionals dedicated to understanding client needs and delivering quality workforce solutions.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Industries Section */}
      <section id="services" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-red-600 mb-4 text-center">Industries We Serve</h2>
          <p className="text-center text-gray-600 mb-12 text-lg">Expertise across diverse sectors in Gulf countries</p>
          
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { name: "Civil Construction", img: "/manus-storage/civil-construction_699bcf60_dfd10f1b.png" },
              { name: "Mechanical Industry", img: "/manus-storage/mechanical-industry_e91f4c9e_14cb574d.png" },
              { name: "Aluminium & Façade", img: "/manus-storage/aluminium-facade_389af436_f6bea0f3.png" },
              { name: "Steel & Fabrication", img: "/manus-storage/steel-fabrication_47c63c70_cb77e942.png" },
              { name: "Oil & Gas Industry", img: "/manus-storage/oil-gas-industry_107bb9ed_ffee0910.png" },
              { name: "MEP Industry", img: "/manus-storage/mep-industry_4d1d075a_36df5472.png" },
              { name: "Signage Industry", img: "/manus-storage/signage-industry_d69dc117_77c8cf3a.png" },
              { name: "PPF Industry", img: "/manus-storage/ppf-film-industry_5294cc68_08c671e6.png" }
            ].map((industry) => (
              <div key={industry.name} className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition border">
                <img src={industry.img} alt={industry.name} className="w-full h-40 object-cover" />
                <div className="p-4 text-center">
                  <h3 className="text-lg font-semibold text-gray-900">{industry.name}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Manpower Categories */}
      <section id="manpower" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-red-600 mb-4 text-center">Manpower Categories</h2>
          <p className="text-center text-gray-600 mb-12 text-lg">Wide range of skilled and semi-skilled workforce available</p>
          
          <div className="grid md:grid-cols-5 gap-4">
            {[
              "Aluminium Fitters", "Glass Fitters", "Fabricators", "Steel Fitters", "Welders",
              "Pipe Fitters", "Electricians", "Plumbers", "HVAC Technicians", "MEP Technicians",
              "Shuttering Carpenters", "Helpers", "Masons", "Civil Technicians", "Mechanical Technicians",
              "Oil & Gas Technicians", "Signage Technicians", "Film PPF Technicians", "General Labourers"
            ].map((category) => (
              <div key={category} className="bg-white p-4 rounded-lg text-center border-l-4 border-red-600 shadow-sm">
                <p className="text-sm font-semibold text-gray-700">{category}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Training Centers */}
      <section id="training" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-red-600 mb-4 text-center">Training Centers</h2>
          <p className="text-center text-gray-600 mb-12 text-lg">Professional training facilities across India</p>
          
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="rounded-lg overflow-hidden shadow-lg">
              <img src="/manus-storage/training-center-mumbai_2da667ed_3f776f9f.png" alt="Mumbai Training Center" className="w-full h-64 object-cover" />
              <div className="p-6 bg-red-50">
                <h3 className="text-2xl font-bold text-red-600 mb-2">Mumbai Training Center</h3>
                <p className="text-gray-700">Specializing in Aluminium Fitters, Fabricators, and Silicon Testing</p>
              </div>
            </div>
            <div className="rounded-lg overflow-hidden shadow-lg">
              <img src="/manus-storage/training-center-delhi_2b1e8f3c_77b6d9e8.png" alt="Delhi Training Center" className="w-full h-64 object-cover" />
              <div className="p-6 bg-red-50">
                <h3 className="text-2xl font-bold text-red-600 mb-2">Delhi Training Center</h3>
                <p className="text-gray-700">Comprehensive training programs for various skilled trades</p>
              </div>
            </div>
          </div>

          {/* Interview Schedule */}
          <div className="bg-gray-50 p-8 rounded-lg mb-12">
            <h3 className="text-2xl font-bold text-red-600 mb-6">Interview Schedule & Test Centers</h3>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h4 className="text-xl font-bold text-gray-900 mb-4">Upcoming Interviews</h4>
                <ul className="space-y-3 text-gray-700">
                  <li>• Dubai - Civil Construction <span className="font-semibold">June 28</span></li>
                  <li>• Abu Dhabi - Mechanical <span className="font-semibold">July 2</span></li>
                  <li>• Doha - MEP Technicians <span className="font-semibold">July 5</span></li>
                </ul>
              </div>
              <div>
                <h4 className="text-xl font-bold text-gray-900 mb-4">Test Center Locations</h4>
                <ul className="space-y-3 text-gray-700">
                  <li>• Mumbai - Aluminium & Fabrication Testing</li>
                  <li>• Delhi - Multi-Trade Testing Center</li>
                  <li>• Bangalore - Technical Assessment Center</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Client Interviews Videos */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold text-red-600 mb-6">Client Interviews</h3>
            <p className="text-gray-600 mb-6">Success stories from our satisfied clients</p>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="rounded-lg overflow-hidden shadow-lg">
                <video width="100%" height="300" controls className="w-full bg-black">
                  <source src="/manus-storage/interview1_67e564e4_ce4ae2f6.mp4" type="video/mp4" />
                  Your browser does not support the video tag.
                </video>
                <div className="p-4 bg-gray-50">
                  <p className="font-semibold text-gray-900">Client Interview 1</p>
                </div>
              </div>
              <div className="rounded-lg overflow-hidden shadow-lg">
                <video width="100%" height="300" controls className="w-full bg-black">
                  <source src="/manus-storage/interview2_fe23a5c9_245d9821.mp4" type="video/mp4" />
                  Your browser does not support the video tag.
                </video>
                <div className="p-4 bg-gray-50">
                  <p className="font-semibold text-gray-900">Client Interview 2</p>
                </div>
              </div>
            </div>
          </div>

          {/* Training Videos Section 1 */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold text-red-600 mb-2">Training Center Mumbai - Aluminium Fitter/Fabricator & Silicon Test Center</h3>
            <p className="text-gray-600 mb-6">Professional training and certification for aluminium fitters and fabricators</p>
            <img src="/manus-storage/training-center-mumbai_2da667ed_3f776f9f.png" alt="Training Center Mumbai" className="w-full h-64 object-cover rounded-lg mb-6" />
            <h4 className="text-xl font-bold text-gray-900 mb-4">Training Videos</h4>
            <div className="grid md:grid-cols-4 gap-4">
              {[
                { src: "/manus-storage/aluminum2_bbb46268_7602b022.mp4", title: "Video 1" },
                { src: "/manus-storage/silicon_0e29e424_ec8c53de.mp4", title: "Video 2" },
                { src: "/manus-storage/mumbai_75886eb9_7448c93c.mp4", title: "Video 3" },
                { src: "/manus-storage/delhi_76a12da3_3638c9de.mp4", title: "Video 4" }
              ].map((video, idx) => (
                <div key={idx} className="rounded-lg overflow-hidden shadow-md">
                  <video width="100%" height="150" controls className="w-full bg-black">
                    <source src={video.src} type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                  <div className="p-2 bg-gray-50">
                    <p className="text-sm font-semibold text-gray-900">{video.title}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Spray Painter Videos */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold text-red-600 mb-2">Spray Painter, Welders & Film PPF Test Center - Training Videos</h3>
            <p className="text-gray-600 mb-6">Professional training and testing facilities for spray painters, welders, and PPF technicians</p>
            <img src="/manus-storage/test-center_b8b0bf2f_55679e6f.png" alt="Test Center" className="w-full h-64 object-cover rounded-lg mb-6" />
            <h4 className="text-xl font-bold text-gray-900 mb-4">Test Center Videos</h4>
            <div className="grid md:grid-cols-4 gap-4">
              {[
                { src: "/manus-storage/spray1_071d0155_c6234c67.mp4", title: "Video 1" },
                { src: "/manus-storage/spray2_e2fcc899_ee55866e.mp4", title: "Video 2" },
                { src: "/manus-storage/spray3_f1815f70_3d8128b1.mp4", title: "Video 3" },
                { src: "/manus-storage/spray4_23aec022_2ff2a22b.mp4", title: "Video 4" }
              ].map((video, idx) => (
                <div key={idx} className="rounded-lg overflow-hidden shadow-md">
                  <video width="100%" height="150" controls className="w-full bg-black">
                    <source src={video.src} type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                  <div className="p-2 bg-gray-50">
                    <p className="text-sm font-semibold text-gray-900">{video.title}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-red-600 mb-4 text-center">Why Choose Us</h2>
          <p className="text-center text-gray-600 mb-12 text-lg">Reasons to partner with AL NOOR TRAVEL AGENCY</p>
          
          <div className="grid md:grid-cols-2 gap-8">
            {[
              { title: "Trusted Overseas Recruitment Partner", desc: "Proven track record in Gulf recruitment with satisfied clients" },
              { title: "Skilled Workforce", desc: "Access to pre-vetted, qualified professionals" },
              { title: "Fast Documentation", desc: "Streamlined visa and documentation process" },
              { title: "Reliable Gulf Placement", desc: "Strong network across UAE, Saudi Arabia, Qatar, and Bahrain" },
              { title: "Industry Specialists", desc: "Expert knowledge across multiple sectors" },
              { title: "Training Facilities", desc: "In-house training centers in Mumbai and New Delhi" },
              { title: "Professional Recruitment Process", desc: "Transparent and ethical recruitment practices" }
            ].map((item, idx) => (
              <div key={idx} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition border-l-4 border-red-600">
                <h3 className="text-xl font-bold text-red-600 mb-2">{item.title}</h3>
                <p className="text-gray-700">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-red-600 mb-4 text-center">Contact Us</h2>
          <p className="text-center text-gray-600 mb-12 text-lg">Get in touch with us for recruitment inquiries</p>
          
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-red-600 mb-6">Address</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">AL NOOR TRAVEL AGENCY</h4>
                  <p className="text-gray-700 leading-relaxed">
                    G10, Kohinoor City Mall,<br />
                    Opp. Holy Cross School,<br />
                    Near Vidyavihar Railway Station,<br />
                    Kurla (W), Mumbai – 400070
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Contact Numbers</h4>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-gray-600">📞 Ramzan:</p>
                      <a href="tel:+918898805256" className="text-red-600 hover:text-red-700 font-semibold">
                        +91 8898805256
                      </a>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">📞 Ramzan:</p>
                      <a href="tel:+918828317105" className="text-red-600 hover:text-red-700 font-semibold">
                        +91 8828317105
                      </a>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">📞 Office:</p>
                      <a href="tel:+919324884858" className="text-red-600 hover:text-red-700 font-semibold">
                        +91 9324884858
                      </a>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">📧 Email:</p>
                      <a href="mailto:alnoortravelagency5@gmail.com" className="text-red-600 hover:text-red-700 font-semibold">
                        alnoortravelagency5@gmail.com
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Email Address</label>
                <input
                  type="email"
                  name="email"
                  placeholder="your@email.com"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-red-600"
                  required
                />
              </div>
              <input
                type="text"
                name="name"
                placeholder="Your name"
                value={formData.name}
                onChange={handleInputChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-red-600"
                required
              />
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Phone Number</label>
                <input
                  type="tel"
                  name="phone"
                  placeholder="+91 XXXXXXXXXX"
                  value={formData.phone}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-red-600"
                />
              </div>
              <textarea
                name="message"
                placeholder="Your message"
                value={formData.message}
                onChange={handleInputChange}
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-red-600"
                required
              />
              <Button 
                type="submit" 
                className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3"
                disabled={sendMessageMutation.isPending}
              >
                {sendMessageMutation.isPending ? "Sending..." : "Send Message"}
              </Button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-red-600 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="text-xl font-bold mb-4">AL NOOR</h4>
              <p className="text-red-100">Your trusted partner in Gulf recruitment and overseas placement services.</p>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-red-100">
                <li><a href="#home" className="hover:text-white transition">Home</a></li>
                <li><a href="#about" className="hover:text-white transition">About Us</a></li>
                <li><a href="#services" className="hover:text-white transition">Services</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">Services</h4>
              <ul className="space-y-2 text-red-100">
                <li><a href="#training" className="hover:text-white transition">Training</a></li>
                <li><a href="#manpower" className="hover:text-white transition">Placement</a></li>
                <li><a href="#contact" className="hover:text-white transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">Follow Us</h4>
              <div className="flex gap-4">
                <a href="#" className="hover:text-red-100 transition">Facebook</a>
                <a href="#" className="hover:text-red-100 transition">LinkedIn</a>
                <a href="#" className="hover:text-red-100 transition">Instagram</a>
              </div>
            </div>
          </div>
          <div className="border-t border-red-500 pt-8 text-center text-red-100">
            <p>&copy; 2026 AL NOOR TRAVEL AGENCY. All rights reserved.</p>
            <p className="mt-4 text-sm">Developed by <span className="font-semibold">ANSHU YADAV</span> | Phone: <a href="tel:+917482014332" className="hover:text-white transition">+91 7482014332</a></p>
          </div>
        </div>
      </footer>
    </div>
  );
}
