# Quick GitHub Pages Deployment - 5 Minutes

## 🚀 Fast Track to Live Website

### Step 1: Create GitHub Repository
```
Go to: https://github.com/new
- Name: al-noor-travel-agency
- Visibility: Public
- Click: Create repository
```

### Step 2: Push Your Code
```bash
# In your project folder
git init
git add .
git commit -m "AL NOOR Travel Agency - Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/al-noor-travel-agency.git
git push -u origin main
```

### Step 3: Enable GitHub Pages
```
1. Go to repository Settings
2. Click Pages (left sidebar)
3. Source: Select "GitHub Actions"
4. Save
```

### Step 4: Wait for Deployment
- Go to Actions tab
- Wait for workflow to complete (2-3 minutes)
- Your site will be live at: https://YOUR_USERNAME.github.io/al-noor-travel-agency

---

## 📝 What Happens Automatically

✅ Code pushed to GitHub  
✅ GitHub Actions workflow triggers  
✅ Dependencies installed  
✅ Website built  
✅ Deployed to GitHub Pages  
✅ Live and accessible  

---

## 🔄 Future Updates

Just push code to main branch:
```bash
git add .
git commit -m "Update: Your changes"
git push
```

Website updates automatically! 🎉

---

## 🎯 Custom Domain (Optional)

Update your domain registrar DNS to point to:
```
A Records:
185.199.108.153
185.199.109.153
185.199.110.153
185.199.111.153

Or CNAME:
YOUR_USERNAME.github.io
```

Then in GitHub Settings → Pages, add custom domain.

---

## ❓ Need Help?

- GitHub Pages Docs: https://docs.github.com/en/pages
- AL NOOR Support: +91 7482014332 (Anshu Yadav)
