# GitHub Pages Deployment Guide

## AL NOOR Travel Agency Website - GitHub Pages Setup

This guide will help you deploy the AL NOOR Travel Agency website to GitHub Pages.

---

## Prerequisites

- GitHub account (https://github.com)
- Git installed on your computer
- Node.js and pnpm installed

---

## Step 1: Create a GitHub Repository

1. Go to https://github.com/new
2. Fill in the repository details:
   - **Repository name**: `al-noor-travel-agency`
   - **Description**: "AL NOOR Travel Agency - Gulf Recruitment & Overseas Placement"
   - **Visibility**: Public
3. Click "Create repository"

---

## Step 2: Push Code to GitHub

1. Extract the ZIP file on your computer
2. Open Terminal/Command Prompt in the extracted folder
3. Run these commands:

```bash
# Initialize git
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit - AL NOOR Travel Agency website"

# Rename branch to main
git branch -M main

# Add remote repository (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/al-noor-travel-agency.git

# Push to GitHub
git push -u origin main
```

---

## Step 3: Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **Settings** (top right)
3. Scroll down to **Pages** section
4. Under "Build and deployment":
   - **Source**: Select "GitHub Actions"
   - This will automatically use the workflow file we created

---

## Step 4: Automatic Deployment

The GitHub Actions workflow will:
- ✅ Automatically trigger on every push to `main` branch
- ✅ Install dependencies using pnpm
- ✅ Build the website
- ✅ Deploy to GitHub Pages

Your website will be live at: `https://YOUR_USERNAME.github.io/al-noor-travel-agency`

---

## Step 5: Custom Domain (Optional)

To use a custom domain like `al-noor-travel.com`:

1. Go to your domain registrar (GoDaddy, Namecheap, etc.)
2. Update DNS records to point to GitHub Pages:
   - Add A records pointing to GitHub's IP addresses
   - Or add CNAME record pointing to `YOUR_USERNAME.github.io`

3. In GitHub repository:
   - Go to **Settings** → **Pages**
   - Under "Custom domain", enter your domain: `al-noor-travel.com`
   - Check "Enforce HTTPS"

---

## Workflow File Details

The `.github/workflows/deploy.yml` file:
- Runs on every push to `main` branch
- Uses Node.js 18.x
- Installs pnpm and dependencies
- Builds the production version
- Deploys to GitHub Pages automatically

---

## Troubleshooting

### Build Fails
- Check that all dependencies are installed: `pnpm install`
- Verify Node.js version: `node --version`

### Pages Not Updating
- Check GitHub Actions tab for workflow errors
- Ensure branch is set to `main` in Pages settings

### Custom Domain Not Working
- Wait 24 hours for DNS propagation
- Check DNS records are correct
- Verify CNAME file is created in repository

---

## Next Steps

1. **Monitor Deployments**: Go to Actions tab to see deployment status
2. **Update Content**: Make changes locally, commit, and push to auto-deploy
3. **Add Analytics**: Track visitor behavior on your website
4. **SEO Optimization**: Add meta tags and structured data

---

## Support

For GitHub Pages issues: https://docs.github.com/en/pages

For AL NOOR Travel Agency website support: Contact Anshu Yadav (+91 7482014332)
