import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import nodemailer from "nodemailer";
import { ENV } from "./_core/env";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  contact: router({
    sendMessage: publicProcedure
      .input(
        z.object({
          name: z.string().min(1, "Name is required"),
          email: z.string().email("Invalid email"),
          phone: z.string().optional(),
          message: z.string().min(1, "Message is required"),
        })
      )
      .mutation(async ({ input }) => {
        try {
          // Create transporter using Gmail
          const transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
              user: ENV.gmailUser,
              pass: ENV.gmailAppPassword,
            },
          });

          // Email to owner
          await transporter.sendMail({
            from: ENV.gmailUser,
            to: ENV.gmailUser,
            subject: `New Contact Form Submission from ${input.name}`,
            html: `
              <h2>New Contact Form Submission</h2>
              <p><strong>Name:</strong> ${input.name}</p>
              <p><strong>Email:</strong> ${input.email}</p>
              <p><strong>Phone:</strong> ${input.phone || "Not provided"}</p>
              <p><strong>Message:</strong></p>
              <p>${input.message.replace(/\n/g, "<br />")}</p>
            `,
          });

          // Confirmation email to user
          await transporter.sendMail({
            from: ENV.gmailUser,
            to: input.email,
            subject: "Thank you for contacting AL NOOR TRAVEL AGENCY",
            html: `
              <h2>Thank you for your inquiry</h2>
              <p>Dear ${input.name},</p>
              <p>We have received your message and will get back to you as soon as possible.</p>
              <p>Best regards,<br />AL NOOR TRAVEL AGENCY Team</p>
            `,
          });

          return { success: true, message: "Email sent successfully" };
        } catch (error) {
          console.error("Email send error:", error);
          throw new Error("Failed to send email. Please try again later.");
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
