# Netlify Deployment - 10 Minutes

## 🚀 Fast Track Setup

### Step 1: Create Netlify Account
```
Go to: https://netlify.com
Click: Sign up with GitHub
Authorize Netlify
```

### Step 2: Connect Repository
```
1. Click: Add new site
2. Select: Import an existing project
3. Choose: GitHub
4. Select: al-noor-travel-agency
5. Click: Install
```

### Step 3: Verify Build Settings
```
Build Command: pnpm install && pnpm run build
Publish Directory: dist
Node Version: 18.17.0
```

### Step 4: Deploy
```
Click: Deploy site
Wait: 2-3 minutes
Live at: https://your-site-name.netlify.app
```

---

## 📝 Environment Variables

In Netlify Dashboard → Site settings → Environment:

```
VITE_APP_TITLE = AL NOOR Travel Agency
VITE_APP_LOGO = AL NOOR
NODE_ENV = production
```

---

## 🔄 Automatic Updates

Push to GitHub → Netlify automatically deploys! ✅

---

## 🎯 Custom Domain

1. Go to: Domain management
2. Add custom domain
3. Update DNS records
4. Done!

---

## ❓ Need Help?

- Netlify Docs: https://docs.netlify.com
- AL NOOR Support: +91 7482014332
